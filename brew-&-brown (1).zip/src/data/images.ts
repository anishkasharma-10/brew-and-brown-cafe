/**
 * Curated high-resolution photography for Brew & Brown Cafe.
 * Centralized to allow quick replacement and consistent aesthetics.
 */

export const HERO_SLIDESHOW_IMAGES = [
  {
    id: 'hero-1',
    title: 'Cozy Cafe Interior with Warm Lighting',
    subtitle: 'Ambient golden hour reflections & rustic warmth',
    url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-2',
    title: 'Warm Brownie with Melting Vanilla Ice Cream',
    subtitle: 'Signature hot fudge sizzle & handcrafted scoop',
    url: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-3',
    title: 'Freshly Baked Woodfired Artisan Pizza',
    subtitle: 'San Marzano tomatoes, fresh mozzarella & sweet basil',
    url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-4',
    title: 'Artisan Cafe Espresso & Velvet Latte Art',
    subtitle: 'Single-origin roast brewed to velvety perfection',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-5',
    title: 'Vibrant Tropical Mocktail with Fresh Mint',
    subtitle: 'Crisp citrus fizz & botanical syrups',
    url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-6',
    title: 'Decadent Fudgy Chocolate Brownies',
    subtitle: 'Loaded with melted Belgian chocolate chunks',
    url: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-7',
    title: 'Beautiful Ambient Cafe Seating & Wood Aesthetics',
    subtitle: 'Sunlit corners, book nooks & conversation spaces',
    url: 'https://images.unsplash.com/photo-1521017432531-fbd92d768814?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-8',
    title: 'Artisan Bakery & Fresh Dessert Counter',
    subtitle: 'Daily baked tarts, cheesecakes & cinnamon rolls',
    url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-9',
    title: 'Aesthetic Cafe Dessert Spread & Coffee',
    subtitle: 'Fluffy waffles, chocolate cakes & iced brew',
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-10',
    title: 'Cozy Evening Cafe with Ambient Fairy Lights',
    subtitle: 'Warm street-side glow and mellow acoustics',
    url: 'https://images.unsplash.com/photo-1445116572660-238429888259?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-11',
    title: 'Barista Counter with Warm Brass & Ambient Glow',
    subtitle: 'Crafting specialty roasts with precision',
    url: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 'hero-12',
    title: 'Lavish Cafe Table Feast & Good Times',
    subtitle: 'Pizzas, pasta, shakes, and sweet finales',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=2000&auto=format&fit=crop',
  },
];

export const CATEGORY_CARD_IMAGES = {
  brownies: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?q=80&w=1200&auto=format&fit=crop',
  pizzas: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=1200&auto=format&fit=crop',
  mocktails: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=1200&auto=format&fit=crop',
  desserts: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=1200&auto=format&fit=crop',
};

export const ABOUT_IMAGES = {
  founderOrBarista: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop',
  ovenBaking: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=1200&auto=format&fit=crop',
  interiorWarm: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=1200&auto=format&fit=crop',
  coffeeCraft: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop',
};
