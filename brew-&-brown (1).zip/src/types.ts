export interface Product {
  id: string;
  name: string;
  category: 'Brownies' | 'Pizzas' | 'Mocktails' | 'Desserts' | 'Beverages' | 'Snacks' | 'Pasta';
  price: number;
  description: string;
  image: string;
  isSpecialty?: boolean;
  isBestSeller?: boolean;
  isVeg?: boolean;
  ingredients?: string[];
  sizes?: {
    name: 'Regular' | 'Medium' | 'Large';
    priceMultiplier?: number;
    extraPrice?: number;
  }[];
}

export interface CartItem {
  id: string; // unique item cart id: productId + size
  productId: string;
  name: string;
  category: string;
  image: string;
  price: number;
  quantity: number;
  size?: 'Regular' | 'Medium' | 'Large';
  specialInstructions?: string;
}

export interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
  diningOption: 'delivery' | 'takeaway' | 'dine-in';
  paymentMethod: 'upi' | 'card' | 'cod';
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  items: CartItem[];
  customer: CustomerDetails;
  subtotal: number;
  deliveryFee: number;
  tax: number;
  total: number;
  createdAt: string;
  estimatedTime: string;
  status: 'confirmed' | 'preparing' | 'ready';
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatar: string;
  comment: string;
  rating: number;
  favouriteItem: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'All' | 'Interiors' | 'Brownies' | 'Pizzas' | 'Mocktails' | 'Coffee & Desserts';
  image: string;
  description: string;
}
